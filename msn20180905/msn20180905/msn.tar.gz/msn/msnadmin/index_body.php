<?php 
include("./templates/index_body.html");