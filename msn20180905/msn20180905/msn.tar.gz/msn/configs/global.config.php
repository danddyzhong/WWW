<?php 
define('ROOTCFG',str_replace("\\", '/', dirname(__FILE__) ));
define('ROOTINC',str_replace("\\", '/', dirname(__FILE__) )."/../includes");
define('ROOTPATH',str_replace("\\", '/', dirname(__FILE__) )."/../");