
<?php

// $smarty->assign('name','Ned');

//** un-comment the following line to show the debug console
//$smarty->debugging = true;

header('Location:msnweb/index.php');
exit();

// $smarty->display('index.tpl');
// die('ddd');

