<?php 
define('SMARTY_DIR',str_replace("\\","/",getcwd()).'/includes/Smarty-3.1.32/libs/');